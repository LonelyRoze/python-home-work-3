class JobLauncherApplicationException(Exception):
    pass


class JenkinsServerException(JobLauncherApplicationException):
    pass

